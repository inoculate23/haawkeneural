from taproot.util import PretrainedTextualInversion

__all__ = ["StableDiffusionPretrainedTextualInversion"]

class StableDiffusionPretrainedTextualInversion(PretrainedTextualInversion):
    pass
