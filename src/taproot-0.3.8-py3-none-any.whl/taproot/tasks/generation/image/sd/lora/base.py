from taproot.util import PretrainedLoRA

__all__ = ["StableDiffusionPretrainedLoRA"]

class StableDiffusionPretrainedLoRA(PretrainedLoRA):
    pass
