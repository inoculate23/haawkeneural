from taproot.util import PretrainedLoRA

__all__ = ["StableDiffusionXLPretrainedLoRA"]

class StableDiffusionXLPretrainedLoRA(PretrainedLoRA):
    pass
