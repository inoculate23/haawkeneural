from taproot.modeling.modules.audio.mel_spectrogram import MelSpectrogram
MelSpectrogram # silence importchecker
__all__ = ["MelSpectrogram"]
