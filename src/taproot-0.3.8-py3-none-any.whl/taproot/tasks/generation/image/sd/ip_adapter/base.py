from taproot.util import PretrainedIPAdapter

__all__ = ["StableDiffusionPretrainedIPAdapter"]

class StableDiffusionPretrainedIPAdapter(PretrainedIPAdapter):
    pass
