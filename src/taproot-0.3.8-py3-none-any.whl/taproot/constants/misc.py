__all__ = ["NOTSET"]

class NOTSET:
    pass
