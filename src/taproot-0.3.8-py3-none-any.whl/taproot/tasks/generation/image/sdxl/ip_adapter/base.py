from taproot.util import PretrainedIPAdapter

__all__ = ["StableDiffusionXLPretrainedIPAdapter"]

class StableDiffusionXLPretrainedIPAdapter(PretrainedIPAdapter):
    pass
