__all__ = [
    "GLOBAL_PROMPT_WEIGHT"
]

# Prompting
GLOBAL_PROMPT_WEIGHT = 0.5
